// Dependencies
var awsSdk = require("aws-sdk");
var async = require("async");
var gm = require("gm").subClass({ imageMagick: true });

// Constants
var TARGET_BUCKET = "x-amz-meta-target-bucket";
var TARGET_KEY    = "x-amz-meta-target-key";
var MAX_WIDTH     = 100;
var MAX_HEIGHT    = 100;

// Reference to the S3 service
var s3 = new awsSdk.S3();

exports.handler = function(event, context, callback) {
    // Read options from the event.
    var sourceBucket = event.Records[0].s3.bucket.name;
    var sourceKey    = event.Records[0].s3.object.key;
    var targetBucket = "";
    var targetKey    = "";

    // Determine the image type.
    var typeMatch = sourceKey.match(/\.([^.]*)$/);
    if (!typeMatch) {
        console.error("Cannot determine the image type.");
        return;
    }
    var imageType = typeMatch[1].toLowerCase();
    if (imageType != "jpg" && imageType != "png") {
        console.error("Unsupported image type: " + imageType);
        return;
    }

    async.waterfall([
        function download(next) {
            // Download the image from the source bucket.
            s3.getObject({
                    Bucket: sourceBucket,
                    Key: sourceKey
                },
                next
            );
        },
        function process(response, next) {
            // Retrieve the target bucket and key.
            targetBucket = response.Metadata[TARGET_BUCKET];
            targetKey    = response.Metadata[TARGET_KEY];
            if (!targetBucket && !targetKey) {
                next("Cannot retrieve the target bucket or key.");
                return;
            }
            if (targetBucket == sourceBucket && targetKey == sourceKey) {
                next("The target bucket and key are the same as the source.");
                return;
            }

            // Scale the image to the desired size.
            gm(response.Body).size(function(error, size) {
                if (error) {
                    next(error);
                    return;
                }

                var scalingFactor = Math.min(MAX_WIDTH / size.width, MAX_HEIGHT / size.height);
                var width  = scalingFactor * size.width;
                var height = scalingFactor * size.height;
                this.resize(width, height).toBuffer(imageType, function(error, buffer) {
                    if (error) {
                        next(error);
                    } else {
                        next(null, buffer);
                    }
                });
            });
        },
        function upload(body, next) {
            // Upload the result to the target bucket.
            s3.putObject({
                    Bucket: targetBucket,
                    Key: targetKey,
                    Body: body,
                },
                next
            );
        }],
        function(error) {
            if (error) {
                console.error(
                    "Unable to process " + sourceBucket + "/" + sourceKey +
                    " or upload to " + targetBucket + "/" + targetKey +
                    " due to an error: " + error
                );
            } else {
                console.log(
                    "Successfully processed " + sourceBucket + "/" + sourceKey +
                    " and uploaded to " + targetBucket + "/" + targetKey
                );
            }
        }
    );
};
