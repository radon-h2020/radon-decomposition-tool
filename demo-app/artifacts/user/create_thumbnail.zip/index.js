// Dependencies
var async = require("async");
var awsSdk = require("aws-sdk");
var util = require("util");
var gm = require("gm").subClass({ imageMagick: true });

// Constants
var TARGET_BUCKET = "x-amz-meta-target-bucket";
var TARGET_KEY    = "x-amz-meta-target-key";
var MAX_WIDTH     = 100;
var MAX_HEIGHT    = 100;

// Reference to the S3 service
var s3 = new awsSdk.S3();

exports.handler = function(event, context, callback) {
    // Read options from the event.
    console.log("Reading options from the event:\n", util.inspect(event, { depth: 5 }));
    var srcBucket = event.Records[0].s3.bucket.name;
    var srcKey    = event.Records[0].s3.object.key;
    var trgBucket = "";
    var trgKey    = "";

    // Determine the image type.
    var typeMatch = srcKey.match(/\.([^.]*)$/);
    if (!typeMatch) {
        console.error("Cannot determine the image type.");
        return;
    }
    var imageType = typeMatch[1].toLowerCase();
    if (imageType != "jpg" && imageType != "png") {
        console.error("Unsupported image type: " + imageType);
        return;
    }

    async.waterfall([
        function download(next) {
            // Download the image from the source bucket.
            s3.getObject({
                    Bucket: srcBucket,
                    Key: srcKey
                },
                next
            );
        },
        function process(response, next) {
            // Retrieve the target bucket and key.
            trgBucket = response.Metadata[TARGET_BUCKET];
            trgKey    = response.Metadata[TARGET_KEY];
            if (!trgBucket && !trgKey) {
                next("Cannot retrieve the target bucket or key.");
                return;
            }
            if (trgBucket == srcBucket && trgKey == srcKey) {
                next("The target bucket and key are the same as the source.");
                return;
            }

            // Scale the image to the desired size.
            gm(response.Body).size(function(err, size) {
                if (err) {
                    next(err);
                    return;
                }

                var scalingFactor = Math.min(MAX_WIDTH / size.width, MAX_HEIGHT / size.height);
                var width  = scalingFactor * size.width;
                var height = scalingFactor * size.height;
                this.resize(width, height).toBuffer(imageType, function(err, buffer) {
                    if (err) {
                        next(err);
                    } else {
                        next(null, response.ContentType, buffer);
                    }
                });
            });
        },
        function upload(contentType, data, next) {
            // Upload the result to the target bucket.
            s3.putObject({
                    Bucket: trgBucket,
                    Key: trgKey,
                    Body: data,
                    ContentType: contentType
                },
                next
            );
        }],
        function(err) {
            if (err) {
                console.error(
                    "Unable to process " + srcBucket + "/" + srcKey +
                    " or upload to " + trgBucket + "/" + trgKey +
                    " due to an error: " + err
                );
            } else {
                console.log(
                    "Successfully processed " + srcBucket + "/" + srcKey +
                    " and uploaded to " + trgBucket + "/" + trgKey
                );
            }
            callback(null, "message");
        }
    );
};
